
#' Draws word cloud
#'
#' @param text_table Counts of words.
#' @param num Number od most frequent words to present.
#'
#' @export


plot <- function(text_table,num){
  wordcloud::wordcloud(text_table[1:num,]$words,text_table[1:num,]$num,colors = 'red')
}
