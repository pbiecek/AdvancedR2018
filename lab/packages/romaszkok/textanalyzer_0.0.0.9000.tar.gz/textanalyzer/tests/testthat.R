library(testthat)
library(textanalyzer)

test_check("textanalyzer")
