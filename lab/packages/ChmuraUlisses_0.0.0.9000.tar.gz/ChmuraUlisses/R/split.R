#' Rozbija książkę na słowa.
#'
#' Funcka split() rozbija książkę na pojedyncze słowa i usuwa przecinki i kropki.
#'
#' 
#' @param Książka do rozbicia.
#' 
#' @examples
#' \dontrun{
#' ksiazka <- downloadUlisses()
#' slowa <- split(ksiazka)
#' }
#' 
#' 
#' 
#' @export
#' 
split <-  function(ksiazka){
  ksiazka <- paste(ksiazka, collapse=" ")
  ksiazka <- gsub("[[:punct:]]", "", ksiazka)
  ksiazka <- unlist(strsplit(ksiazka, " ", fixed = TRUE))
  ksiazka
}
