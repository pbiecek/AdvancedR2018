setwd("h:\\Windows7\\Desktop\\R_level_2")
# -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

library(devtools)
library(testthat)
create("ChmuraUlisses")


#ulisses <- readLines("http://www.gutenberg.org/files/4300/4300-0.txt")

document(pkg="ChmuraUlisses")
install("ChmuraUlisses")

library(wordcloud)

use_package(package="RColorBrewer" , pkg="ChmuraUlisses")

wordcloud()

library(ChmuraUlisses)
ksiazka <- downloadUlisses()
slowa <- split(ksiazka)
length(slowa)
names(tab)


use_testthat("ChmuraUlisses")


test("ChmuraUlisses")

check("ChmuraUlisses")

build("ChmuraUlisses")
