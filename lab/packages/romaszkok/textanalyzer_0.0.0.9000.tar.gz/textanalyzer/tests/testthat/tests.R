library(testthat)
library(textanalyzer)

test_that("Result is character",{
  expect_true(is.character(textanalyzer::download("http://www.gutenberg.org/cache/epub/103/pg103.txt")))
})
