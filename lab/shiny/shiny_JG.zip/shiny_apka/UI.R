library(shiny)
library(PogromcyDanych)

dostepneMarki <- sort(levels(auta2012$Marka))
min_rok <- min(auta2012$Rok.produkcji)
max_rok <- max(auta2012$Rok.produkcji)

shinyUI(fluidPage(
  
  titlePanel("Przegląd cen samochodów"),
  sidebarLayout(
    sidebarPanel(
      selectInput("marka", 
                  label = "Wybierz markę samochodu",
                  choices = dostepneMarki,
                  selected = ""),
      
      uiOutput("listaModeli"),
      
      sliderInput("rok",
                  label = "Wybierz rok produkcji",
                  min=min_rok,
                  max=max_rok,
                  value = c(min_rok,max_rok),
                  sep = " ",
                  dragRange=TRUE)
      
        
      
    ),
  mainPanel(
    plotOutput("histogram"),
    tableOutput("tabela")
  )
)
  ))



