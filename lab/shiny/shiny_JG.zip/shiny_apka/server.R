library(PogromcyDanych)


shinyServer(function(input, output, session) {
 
  output$listaModeli <- renderUI({ 
    
    marka_modele <-auta2012[auta2012$Marka==input$marka,8]
        selectInput("modele", "Wybierz model", as.character(marka_modele) )
  })
  
  
  tylkoWybraneAuto <- reactive({
    auta2012[auta2012$Marka==input$marka & auta2012$Model==input$modele & auta2012$Rok.produkcji>=input$rok[1] & auta2012$Rok.produkcji<=input$rok[2],]
  })
  
  
  
  output$histogram = renderPlot({
    auto <- tylkoWybraneAuto()
    
    hist(auto$Cena.w.PLN, las=1)
    
  })
  

  output$tabela <- renderTable({
    tanie <- tylkoWybraneAuto()
    upo <- tanie[order(tanie$Cena),]
    upo[1:5,c(3,4,5,6,12,13,14,15)]
  })
  
  
})

