#' Dostęp do danych umieszczonych np. na stronie projektu Gutenberg
#'
#' Funkcja download() pobiera text w podanego urla
#'
#' @param url url pod którym znajduje się tekts
#'
#' @author 
#' Kamil Romaszko
#' 
#' @examples
#' \dontrun{
#' download("http://www.gutenberg.org/cache/epub/103/pg103.txt")
#' }
#' 
#' @export

download <-function(url) {
  text_lines <- readLines(url)
  full_text <- paste(text_lines, collapse = '')
  full_text <- gsub(",", " ", full_text)
  return(full_text)
}

#' Podział tekstu na słowa
#'
#' Funkcja split() dzieli podany tekst na słowa
#'
#' @param text tekst do przetworzenia
#'
#' @author 
#' Kamil Romaszko
#' 
#' @examples
#' \dontrun{
#' text <- download("http://www.gutenberg.org/cache/epub/103/pg103.txt")
#' splitted_text <- textanalyzer::split(text)
#' }
#' 
#' @export

split <- function(text) {
  return(strsplit(text, c(" ", ",")))
}

#' Rysowanie chmury słów
#'
#' Funkcja plot() rysuje chmurę słów za pomocą pakiety wordcloud
#'
#' @param text tekst do zwizualizowania
#'
#' @author 
#' Kamil Romaszko
#' 
#' @examples
#' \dontrun{
#' text <- download("http://www.gutenberg.org/cache/epub/103/pg103.txt")
#' splitted_text <- textanalyzer::split(text)
#' textanalyzer::plot(splitted_text)
#' }
#' 
#' @export

plot <-function(text) {
  words_table <- table(text)
  wordcloud::wordcloud(names(words_table), as.vector(words_table))
}