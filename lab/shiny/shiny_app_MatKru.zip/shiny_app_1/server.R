library(PogromcyDanych)
library(dplyr)

shinyServer(function(input, output, session) {
  tylkoWybrane <- reactive({
    auta2012[auta2012$Rok.produkcji >= input$Rok[1] &
               auta2012$Rok.produkcji <= input$Rok[2] & 
               auta2012$Marka == input$Marka,]
  })
  tylkoWybraneModel <- reactive({
    sam <- tylkoWybrane()
    sam[sam$Model == input$Model,]
  })
  
  output$Model <- renderUI({ 
    sam <- tylkoWybrane()
    
    selectInput("Model", "Model",unique(sam$Model))
  })
  
  output$hist = renderPlot({
    sam <- tylkoWybraneModel()

    if(length(sam) > 0){
    pl <- ggplot2::qplot(sam$Cena.w.PLN,xlab = 'Cena w PLN') 
    pl
    }
  })
  
  output$tab = renderDataTable({
    sam <- tylkoWybraneModel()
    if(length(sam) > 0){
    head(select(arrange(sam,Cena.w.PLN),c(Cena.w.PLN,Przebieg.w.km,Rodzaj.paliwa,Kolor)))
    }
  })
})



