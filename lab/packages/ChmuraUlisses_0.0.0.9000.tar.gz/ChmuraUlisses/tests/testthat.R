library(testthat)
library(ChmuraUlisses)

test_check("ChmuraUlisses")
