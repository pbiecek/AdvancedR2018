library(shiny)
library(PogromcyDanych)

marki <- sort(unique(auta2012$Marka))


shinyUI(fluidPage(
  titlePanel("Analiza cen samochodów"),
  inputPanel( 
      selectInput("Marka",
                  label = 'Marka',
                  choices = marki,
                  selected = marki[0]),
      sliderInput('Rok',
                  'Rok produkcji',
                  1990,
                  2012,
                  c(1990,2012),
                  step =1,
                  sep=''),
      htmlOutput("Model")),
      tabsetPanel(
        tabPanel("Wykres", 
                 plotOutput("hist")),
        tabPanel("Model",
                 dataTableOutput("tab")
        )    
      )
    )
  )