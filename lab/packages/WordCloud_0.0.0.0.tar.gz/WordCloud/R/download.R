

#' Downloads text file
#'
#' @param link Link to gutenberg txt file.
#'
#' @export


download <- function(link = 'http://www.gutenberg.org/cache/epub/103/pg103.txt'){
  print('Downloading file...')
  dok <- readLines(link)
  print('Done!')
  return(dok)
}
