
#' Simple processing for downloaded file
#'
#' @param text_fil Loaded text file.
#'
#' @export


split <- function(text_fil)
{
  text_fil <- download()
  splited_v1 <- ''
  n <- length(text_fil)
  print('Creating words counts...')
  for (i in 1:n){
    splited_v1 <- paste(splited_v1,text_fil[i],sep='')
  }
  splited_v1 <- gsub(',',' ',gsub('.', ' ',gsub(' {2,}',' ',splited_v1),fixed=T),fixed=T)

  word_counts <- table(strsplit(splited_v1,' ')[[1]])
  word_counts <- word_counts[order(word_counts,decreasing = T)]
  wc_df <- as.data.frame(word_counts)
  colnames(wc_df) <- c('num')
  wc_df$words <- rownames(wc_df)
  rownames(wc_df) <- NULL
  print('Done!')
  return(wc_df)

}


