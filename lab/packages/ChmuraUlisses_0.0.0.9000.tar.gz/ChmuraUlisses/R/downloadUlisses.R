#' Pobiera książkę.
#'
#' Funkcja downloadUlisses() pobiera książkę Ulisses Jamesa Joyce'a.
#'
#'
#' @export
#' 
downloadUlisses <-  function(){
  readLines("http://www.gutenberg.org/files/4300/4300-0.txt")
}
