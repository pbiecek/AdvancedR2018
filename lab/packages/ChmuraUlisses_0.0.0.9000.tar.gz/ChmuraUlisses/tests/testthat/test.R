test_that("Result is a vector",{
  expect_true(is.vector(split("Kia dkgjbdk, srtgds")))
})