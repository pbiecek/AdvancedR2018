#' Rysuje wykres.
#'
#' Funkcja plot_words() rysuje chmurę ze słów.
#'
#' 
#' @param Słowa.
#' @export
#' 
plot_words <-  function(slowa){
  tab <- table(slowa)
  tab <- sort(tab, decreasing = TRUE)
  tab <- tab[1000:10000]
  tab <- tab[sample(1:9000,400)]
  nazwy <- names(tab)
  wordcloud::wordcloud(nazwy, tab, scale=c(1.5,0.2), min.freq=3, random.order = FALSE,
                       colors=RColorBrewer::brewer.pal(9, "BuGn"))
}
